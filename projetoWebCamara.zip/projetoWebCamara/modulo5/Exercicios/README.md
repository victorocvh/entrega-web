Módulo 5 - Lista de Exercício
=========

Para realização desse exercício vamos utilizar os dados do site 'dados abertos' da câmera de deputados federal (https://dadosabertos.camara.leg.br/) temos todas as informações de ações e gastos dos deputados federais. Vamos realizar o cruzamento dessas informações para obter respostas interessantes:


![dadosabertos](https://github.com/clodonil/Python-Fundamentals/blob/master/Imagens/dados_abertos1.png)

Para obter os valores dinamicamente, utilizaremos a biblioteca `Scrapy_DadosAbertos`. Mais a frente vamos entender como foi desenvolvida essa biblioteca, mais agora o importante é saber utiliza-lá.

A biblioteca retorna os dados da API do site dados abertos.

```python
# importa a lib para conexão com o site Dados Abertos
from  lib.scrapy_dadosAbertos import DadosAbertos
# Inicia a class para obter os dados
site_connect = DadosAbertos()
# obtendo ajuda com os métodos disponíveis.
print(site_connect.help())
#Obtendo a lista de Deputados
list_dep = site_connect.deputados()
#Imprimindo a lista de deputados
print(list_dep)

```

Com essa informação, vamos responder as perguntas abaixo. Desenvolva os códigos em Python + Flask.

> Questão de 1-5 serão consideradas para nota.

1. **Desenvolva uma página WEB com os nomes dos partidos e o números de deputados. Ao clicar no partido, uma nova página deve mostrar os nomes dos deputados:**

2. **Apresente um infográficos dos deputados por faixa etária (18 a 24 anos, 25 a 34 anos, 35 a 44 anos, 45 a 54 anos, 55 a 54 anos, 65 a 74 anos e 75 anos ou mais), mostrando os deputados de cada grupo:**
   
3. **Apresente um infográfico dos deputados x deputadas:**

4. **Apresente um infográfico dos gastos dos deputados do mês atual:**
	
5. **Desenvolva uma página WEB que mostra todas as comissões da câmera dos deputados. Ao clicar em uma comissão, deve mostrar as informações mais detalhadas:**

> Questão 6 e 8 são para aprofundamento do conhecimento

```
6. Mostre os gastos mais comum dos deputados:

7. Mostre os nomes dos 3 deputados que tiveram o menor gastos:

8. Mostre os deputados que participam de mais comissão:
```

> Questão 9 e 10 são desafios; só para os valentes, corajosos e fortes. Esqueça você não vai conseguir.

```
9. Mostre todos os votos (a favor ou contra) de um deputado e a descrição dos projetos:

10. Apresente todos os projetos para um usuário e solicite a votaçao para cada projeto. Verifique qual deputado votou mais semestre ao usuário.

```
***
> By:
```python
Autor   = ['Clodonil Honorio Trigo','clodonil@nisled.org']
linkdin = 'https://www.linkedin.com/in/clodonil-trigo-4155722a'
Blog    = 'http://www.devops-sys.com.br'
```
