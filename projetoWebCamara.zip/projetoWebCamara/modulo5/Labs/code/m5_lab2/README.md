# **Construa uma aplicação WEB que mostra uma tabela com cadastro do deputado (Foto,Nome, Estado e Partido); ao clicar no nome do deputado, uma nova janela apresenta o cadastro completa do deputado**

## Tela1
![lab2_1](img/lab2_1.png)

## Tela2
![lab2_2](img/lab2_2.png)