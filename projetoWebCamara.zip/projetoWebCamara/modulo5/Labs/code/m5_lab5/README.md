# **Faça um gráfico com a relação de proposições x partidos:**


![lab5](img/lab5.png)