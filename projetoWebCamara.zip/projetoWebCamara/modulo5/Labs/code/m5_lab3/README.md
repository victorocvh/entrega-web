# **Construa uma aplicação WEB que mostra uma tabela com cadastro do deputado (Foto, Nome, Estado e Partido), adicione um link para mostrar os gastos do deputado;**

## Tela1
![lab3_1](img/lab3_1.png)

## Tela2
![lab3_3](img/lab3_2.png)