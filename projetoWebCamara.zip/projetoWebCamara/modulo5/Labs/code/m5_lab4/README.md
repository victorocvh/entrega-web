# **Faça um gráfico dos deputados por partidos:**


![lab4](img/lab4.png)